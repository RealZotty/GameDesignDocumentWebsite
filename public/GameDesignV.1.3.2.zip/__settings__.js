window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "1924011.json";
window.CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'deviceTypes': [`webgl2`, `webgl1`],
    'powerPreference': "high-performance"
};
window.SCRIPTS = [ 159897247, 159904127, 159950161, 162481575, 162481950, 162844346, 162844816, 163259186, 163259505, 164052132, 167194984, 173214599, 173215029, 173215076 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/159890594/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/159890595/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/159890593/1/ammo.js', 'preload' : true},
];
